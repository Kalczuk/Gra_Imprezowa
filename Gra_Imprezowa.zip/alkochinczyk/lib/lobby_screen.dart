import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'player_names_screen.dart';
import 'game_board_screen.dart';

// --- ZUNIFIKOWANY EKRAN USTAWIENIA GRACZA (NICK, KOLOR, KOD, MAX GRACZY) ---
class LobbySetupScreen extends StatefulWidget {
  final bool isHost;
  const LobbySetupScreen({Key? key, required this.isHost}) : super(key: key);

  @override
  State<LobbySetupScreen> createState() => _LobbySetupScreenState();
}

class _LobbySetupScreenState extends State<LobbySetupScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();
  Color _selectedColor = Colors.blueAccent;
  int _maxPlayers = 4;

  final List<Color> _availableColors = [
    Colors.redAccent, Colors.blueAccent, Colors.greenAccent, Colors.yellowAccent, Colors.purpleAccent, Colors.orangeAccent, Colors.cyanAccent, Colors.pinkAccent
  ];

  void _submit() async {
    String nick = _nameController.text.trim();
    if (nick.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Musisz podać swój Nick!'))); return; }

    if (widget.isHost) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LobbyRoomScreen(roomCode: null, playerName: nick, playerColor: _selectedColor, maxPlayers: _maxPlayers)));
    } else {
      String code = _codeController.text.trim().toUpperCase();
      if (code.length != 4) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kod musi mieć dokładnie 4 znaki!'))); return; }

      var doc = await FirebaseFirestore.instance.collection('lobbies').doc(code).get();
      if (doc.exists) {
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LobbyRoomScreen(roomCode: code, playerName: nick, playerColor: _selectedColor)));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Taki pokój nie istnieje!')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141E30),
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(40.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(widget.isHost ? 'KREATOR GRY' : 'DOŁĄCZASZ DO GRY', style: GoogleFonts.bangers(fontSize: 50, color: widget.isHost ? Colors.blueAccent : Colors.greenAccent)),
              const SizedBox(height: 30),
              TextField(controller: _nameController, textAlign: TextAlign.center, style: GoogleFonts.lato(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold), decoration: InputDecoration(hintText: 'WPISZ SWÓJ NICK', hintStyle: const TextStyle(color: Colors.white38), enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: widget.isHost ? Colors.blueAccent : Colors.greenAccent, width: 3), borderRadius: BorderRadius.circular(20)), focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.white, width: 3), borderRadius: BorderRadius.circular(20)))),
              const SizedBox(height: 30),
              if (!widget.isHost) ...[
                TextField(controller: _codeController, textAlign: TextAlign.center, style: GoogleFonts.rubik(fontSize: 40, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 10), maxLength: 4, textCapitalization: TextCapitalization.characters, decoration: InputDecoration(counterText: "", hintText: 'KOD GRY', hintStyle: const TextStyle(color: Colors.white38, letterSpacing: 2), enabledBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.greenAccent, width: 3), borderRadius: BorderRadius.circular(20)), focusedBorder: OutlineInputBorder(borderSide: const BorderSide(color: Colors.white, width: 3), borderRadius: BorderRadius.circular(20)))),
                const SizedBox(height: 30),
              ],
              if (widget.isHost) ...[
                Text('MAKS. LICZBA GRACZY:', style: GoogleFonts.bangers(fontSize: 26, color: Colors.white)),
                const SizedBox(height: 10),
                Wrap(spacing: 10, children: [2, 3, 4, 5, 6, 7, 8].map((num) { bool isSelected = _maxPlayers == num; return GestureDetector(onTap: () { setState(() { _maxPlayers = num; }); }, child: CircleAvatar(backgroundColor: isSelected ? Colors.blueAccent : Colors.white10, radius: 22, child: Text('$num', style: GoogleFonts.bangers(color: isSelected ? Colors.white : Colors.white54, fontSize: 24)))); }).toList()),
                const SizedBox(height: 30),
              ],
              Text('WYBIERZ SWÓJ KOLOR:', style: GoogleFonts.bangers(fontSize: 26, color: Colors.white)),
              const SizedBox(height: 15),
              Wrap(spacing: 15, runSpacing: 15, alignment: WrapAlignment.center, children: _availableColors.map((color) { bool isSelected = _selectedColor == color; return GestureDetector(onTap: () { setState(() { _selectedColor = color; }); }, child: CircleAvatar(backgroundColor: color, radius: 25, child: isSelected ? const Icon(Icons.check, size: 30, color: Colors.black) : null)); }).toList()),
              const SizedBox(height: 50),
              ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: widget.isHost ? Colors.blueAccent : Colors.greenAccent, padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 20), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))), onPressed: _submit, child: Text(widget.isHost ? 'STWÓRZ POKÓJ' : 'WCHODZĘ!', style: GoogleFonts.bangers(fontSize: 30, color: Colors.white)))
            ],
          ),
        ),
      ),
    );
  }
}

// --- EKRAN LOBBY (POCZEKALNIA WŁAŚCIWA) ---
class LobbyRoomScreen extends StatefulWidget {
  final String? roomCode;
  final String playerName;
  final Color playerColor;
  final int? maxPlayers;

  const LobbyRoomScreen({Key? key, this.roomCode, required this.playerName, required this.playerColor, this.maxPlayers}) : super(key: key);

  @override
  State<LobbyRoomScreen> createState() => _LobbyRoomScreenState();
}

class _LobbyRoomScreenState extends State<LobbyRoomScreen> {
  String currentCode = "";
  List<PlayerData> connectedPlayers = [];
  bool isHost = false;
  String myLocalName = "";
  int currentMaxPlayers = 4;

  StreamSubscription<DocumentSnapshot>? _roomSubscription;
  bool _isStartingGame = false;
  bool _isHostClickingStart = false;

  @override
  void initState() {
    super.initState();
    myLocalName = widget.playerName;

    if (widget.roomCode == null) {
      isHost = true;
      currentMaxPlayers = widget.maxPlayers ?? 4;
      _createRoomInFirebase();
    } else {
      isHost = false;
      currentCode = widget.roomCode!;
      _joinRoomInFirebase();
    }
  }

  @override
  void dispose() { _roomSubscription?.cancel(); super.dispose(); }

  void _generateCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    currentCode = String.fromCharCodes(Iterable.generate(4, (_) => chars.codeUnitAt(Random().nextInt(chars.length))));
  }

  Future<void> _createRoomInFirebase() async {
    _generateCode();
    setState(() {});
    await FirebaseFirestore.instance.collection('lobbies').doc(currentCode).set({'status': 'waiting', 'maxPlayers': currentMaxPlayers, 'players': [{'name': myLocalName, 'color': widget.playerColor.value, 'captainName': myLocalName}]});
    _listenToRoomUpdates();
  }

  Future<void> _joinRoomInFirebase() async {
    try {
      var docRef = FirebaseFirestore.instance.collection('lobbies').doc(currentCode);
      var doc = await docRef.get();

      if (doc.exists) {
        var data = doc.data() as Map<String, dynamic>;
        var playersList = data['players'] as List<dynamic>;
        currentMaxPlayers = data['maxPlayers'] ?? 4;

        if (playersList.length >= currentMaxPlayers) {
          if (mounted) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Pokój jest już pełny! (Maksymalnie $currentMaxPlayers graczy)'))); Navigator.pop(context); }
          return;
        }

        bool nameExists = playersList.any((p) => p['name'] == myLocalName);
        if (nameExists) { myLocalName = "$myLocalName "; }
      }

      await docRef.update({'players': FieldValue.arrayUnion([{'name': myLocalName, 'color': widget.playerColor.value, 'captainName': myLocalName}])});
      _listenToRoomUpdates();
    } catch (e) { debugPrint("Błąd dołączania: $e"); }
  }

  void _listenToRoomUpdates() {
    _roomSubscription = FirebaseFirestore.instance.collection('lobbies').doc(currentCode).snapshots().listen((snapshot) {
      if (snapshot.exists && mounted) {
        var data = snapshot.data() as Map<String, dynamic>;
        var playersList = data['players'] as List<dynamic>;

        if (data['status'] == 'playing') {
          if (!_isStartingGame) {
            _isStartingGame = true;
            _roomSubscription?.cancel();

            var finalPlayersList = playersList.map((p) => PlayerData(name: p['name'], color: Color(p['color']), captainName: p['captainName'])).toList();
            int myIndex = finalPlayersList.indexWhere((p) => p.name == myLocalName);
            if (myIndex == -1) myIndex = 0;

            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => GameBoardScreen(
              players: finalPlayersList,
              roomCode: currentCode,
              localPlayerIndex: myIndex,
            )));
          }
        }
        else {
          setState(() {
            currentMaxPlayers = data['maxPlayers'] ?? 4;
            connectedPlayers = playersList.map((p) => PlayerData(name: p['name'], color: Color(p['color']), captainName: p['captainName'])).toList();
          });
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141E30),
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, title: Text('POCZEKALNIA', style: GoogleFonts.bangers(fontSize: 30, color: Colors.white))),
      body: Center(
        child: Column(
          children: [
            const SizedBox(height: 20),
            Text('KOD GRY:', style: GoogleFonts.lato(fontSize: 20, color: Colors.white70)),
            Text(currentCode, style: GoogleFonts.rubik(fontSize: 80, fontWeight: FontWeight.w900, color: Colors.yellowAccent, letterSpacing: 10, shadows: [const Shadow(blurRadius: 15, color: Colors.yellow)])),
            const SizedBox(height: 40),
            Text('OCZEKIWANIE NA GRACZY (${connectedPlayers.length}/$currentMaxPlayers)...', style: GoogleFonts.lato(fontSize: 18, color: Colors.white)),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: connectedPlayers.length,
                itemBuilder: (context, index) {
                  return Card(
                    color: connectedPlayers[index].name == myLocalName ? Colors.white24 : Colors.white10,
                    margin: const EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                    child: ListTile(
                      leading: Icon(Icons.person, color: connectedPlayers[index].color, size: 40),
                      title: Text(connectedPlayers[index].name + (connectedPlayers[index].name == myLocalName ? " (TY)" : ""), style: GoogleFonts.bangers(fontSize: 26, color: Colors.white)),
                    ),
                  );
                },
              ),
            ),
            if (isHost) Padding(
              padding: const EdgeInsets.all(30.0),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.pinkAccent, padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 20), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                onPressed: (connectedPlayers.length > 1 && !_isHostClickingStart) ? () async {
                  setState(() { _isHostClickingStart = true; });
                  await FirebaseFirestore.instance.collection('lobbies').doc(currentCode).update({'status': 'playing'});
                } : null,
                child: Text('ZACZYNAMY!', style: GoogleFonts.bangers(fontSize: 30, color: Colors.white)),
              ),
            )
          ],
        ),
      ),
    );
  }
}