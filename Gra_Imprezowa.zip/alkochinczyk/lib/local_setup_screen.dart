import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'game_board_screen.dart';
import 'player_names_screen.dart';

class LocalSetupScreen extends StatefulWidget {
  const LocalSetupScreen({Key? key}) : super(key: key);

  @override
  State<LocalSetupScreen> createState() => _LocalSetupScreenState();
}

class _LocalSetupScreenState extends State<LocalSetupScreen> {
  int _playerCount = 4;

  late List<TextEditingController> _nameControllers;
  late List<Color> _selectedColors;

  final List<Color> _availableColors = [
    Colors.redAccent, Colors.blueAccent, Colors.greenAccent,
    Colors.yellowAccent, Colors.purpleAccent, Colors.orangeAccent,
    Colors.cyanAccent, Colors.pinkAccent
  ];

  @override
  void initState() {
    super.initState();
    _nameControllers = List.generate(8, (index) => TextEditingController());
    _selectedColors = List.generate(8, (index) => _availableColors[index % _availableColors.length]);
  }

  @override
  void dispose() {
    for (var c in _nameControllers) { c.dispose(); }
    super.dispose();
  }

  void _startGame() {
    List<PlayerData> players = [];

    for (int i = 0; i < _playerCount; i++) {
      String name = _nameControllers[i].text.trim();
      if (name.isEmpty) {
        name = "Gracz ${i + 1}";
      }

      players.add(PlayerData(
        name: name,
        captainName: name,
        color: _selectedColors[i],
      ));
    }

    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (context, anim1, anim2) => GameBoardScreen(
          players: players,
          roomCode: 'LOCAL',
          localPlayerIndex: 0,
        ),
        transitionsBuilder: (context, anim1, anim2, child) {
          return FadeTransition(opacity: anim1, child: child);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141E30),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 30),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 80),
          child: Center(
            child: Container(
              width: 700,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('GRA LOKALNA', style: GoogleFonts.bangers(fontSize: 50, color: Colors.pinkAccent)),
                  const SizedBox(height: 15),

                  Text('LICZBA GRACZY:', style: GoogleFonts.bangers(fontSize: 26, color: Colors.white)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 15,
                    children: [2, 3, 4, 5, 6, 7, 8].map((num) {
                      bool isSelected = _playerCount == num;
                      return GestureDetector(
                        onTap: () { setState(() { _playerCount = num; }); },
                        child: CircleAvatar(
                          backgroundColor: isSelected ? Colors.pinkAccent : Colors.white10,
                          radius: 25,
                          child: Text('$num', style: GoogleFonts.bangers(color: isSelected ? Colors.white : Colors.white54, fontSize: 26)),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),

                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _playerCount,
                    itemBuilder: (context, index) {
                      return Container(
                        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: _selectedColors[index].withOpacity(0.5), width: 2),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextField(
                              controller: _nameControllers[index],
                              style: GoogleFonts.lato(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                              decoration: InputDecoration(
                                hintText: 'Gracz ${index + 1}',
                                hintStyle: const TextStyle(color: Colors.white54),
                                prefixIcon: Icon(Icons.person, color: _selectedColors[index]),
                                border: InputBorder.none,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 10,
                              children: _availableColors.map((color) {
                                bool isSelected = _selectedColors[index] == color;
                                return GestureDetector(
                                  onTap: () { setState(() { _selectedColors[index] = color; }); },
                                  child: CircleAvatar(
                                    backgroundColor: color,
                                    radius: 18,
                                    child: isSelected ? const Icon(Icons.check, size: 22, color: Colors.black) : null,
                                  ),
                                );
                              }).toList(),
                            )
                          ],
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 25),

                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.pinkAccent,
                      padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      elevation: 5,
                    ),
                    onPressed: _startGame,
                    child: Text('ODPALAMY PLANSZĘ!', style: GoogleFonts.bangers(fontSize: 30, color: Colors.white, letterSpacing: 2)),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}