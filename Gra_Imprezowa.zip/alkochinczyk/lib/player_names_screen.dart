import 'package:flutter/material.dart';

class PlayerData {
  final String name;
  final Color color;
  final String captainName;

  PlayerData({
    required this.name,
    required this.color,
    required this.captainName,
  });
}