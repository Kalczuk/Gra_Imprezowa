import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'local_setup_screen.dart';
import 'lobby_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Wymuszenie orientacji pionowej
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]).then((_) {
    runApp(const AlkoChinczykApp());
  });
}

class AlkoChinczykApp extends StatelessWidget {
  const AlkoChinczykApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Alkochińczyk',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.deepPurple,
      ),
      home: const AppSplashScreen(),
    );
  }
}

// --- EKRAN ŁADOWANIA (SPLASH SCREEN) NA START APLIKACJI ---
class AppSplashScreen extends StatefulWidget {
  const AppSplashScreen({Key? key}) : super(key: key);

  @override
  State<AppSplashScreen> createState() => _AppSplashScreenState();
}

class _AppSplashScreenState extends State<AppSplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat();

    Timer(const Duration(milliseconds: 3500), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const MainAppScreen()),
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141E30),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                colors: [Color(0xFF243B55), Color(0xFF141E30)],
                center: Alignment.center,
                radius: 1.2,
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                RotationTransition(
                  turns: _controller,
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      double scale = 1.0 + (sin(_controller.value * 2 * pi) * 0.1);
                      return Transform.scale(
                        scale: scale,
                        child: const Icon(Icons.sports_bar, size: 110, color: Colors.amberAccent),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 50),
                Text(
                  'ŁADOWANIE IMPREZY...',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.bangers(
                    fontSize: 34,
                    color: Colors.pinkAccent,
                    letterSpacing: 2,
                    shadows: [const Shadow(blurRadius: 10.0, color: Colors.black, offset: Offset(2.0, 2.0))],
                  ),
                ),
                const SizedBox(height: 35),
                SizedBox(
                  width: 320,
                  height: 8,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: const LinearProgressIndicator(
                      backgroundColor: Colors.white10,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.pinkAccent),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// --- MENU GŁÓWNE ---
class MainAppScreen extends StatelessWidget {
  const MainAppScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                colors: [Color(0xFF3a1c71), Color(0xFFd76d77), Color(0xFFffaf7b)],
                center: Alignment.center,
                radius: 1.5,
              ),
            ),
          ),
          Positioned(top: size.height * 0.1, left: size.width * 0.1, child: _buildBackgroundIcon(Icons.casino, 60, -0.2)),
          Positioned(bottom: size.height * 0.1, right: size.width * 0.15, child: _buildBackgroundIcon(Icons.local_drink, 80, 0.4)),
          Positioned(top: size.height * 0.2, right: size.width * 0.05, child: _buildBackgroundIcon(Icons.style, 50, 0.2)),
          Positioned(bottom: size.height * 0.2, left: size.width * 0.2, child: _buildBackgroundIcon(Icons.sports_bar, 70, -0.3)),

          SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'ALKOCHIŃCZYK',
                        style: GoogleFonts.bangers(
                          fontSize: 72,
                          color: Colors.amberAccent,
                          letterSpacing: 6,
                          shadows: [const Shadow(blurRadius: 2.0, color: Colors.black, offset: Offset(2.0, 2.0))],
                        ),
                      ),
                      const SizedBox(height: 30),
                      _buildGameButton(
                        context,
                        title: 'GRA NA JEDNYM TELEFONIE',
                        icon: Icons.smartphone,
                        color: Colors.pinkAccent,
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const LocalSetupScreen()));
                        },
                      ),
                      const SizedBox(height: 15),
                      _buildGameButton(
                        context,
                        title: 'STWÓRZ LOBBY',
                        icon: Icons.add_circle,
                        color: Colors.deepPurpleAccent,
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const LobbySetupScreen(isHost: true)));
                        },
                      ),
                      const SizedBox(height: 15),
                      _buildGameButton(
                        context,
                        title: 'DOŁĄCZ DO LOBBY',
                        icon: Icons.login,
                        color: Colors.tealAccent.shade400,
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const LobbySetupScreen(isHost: false)));
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackgroundIcon(IconData icon, double size, double rotation) {
    return Transform.rotate(angle: rotation, child: Icon(icon, size: size, color: Colors.white.withOpacity(0.1)));
  }

  Widget _buildGameButton(BuildContext context, {required String title, required IconData icon, required Color color, required VoidCallback onPressed}) {
    return SizedBox(
      width: 320,
      height: 55,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
            side: BorderSide(color: Colors.white.withOpacity(0.2), width: 2),
          ),
          elevation: 4,
        ),
        icon: Icon(icon, size: 26, color: Colors.white),
        label: Text(title, style: GoogleFonts.lato(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        onPressed: onPressed,
      ),
    );
  }
}