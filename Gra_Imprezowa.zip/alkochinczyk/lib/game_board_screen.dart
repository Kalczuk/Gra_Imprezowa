import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flame/game.dart';
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/input.dart';
import 'package:flame/effects.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'player_names_screen.dart';

enum TileType { normal, drink, card, start, home }
enum GamePhase { introAnimation, initRolling, playingRolling, playingMoving, animatingMove, actionMenu, duelRolling, waitingForCardPick, waitingForCardFlip }

class AlkoChinczykGame extends FlameGame with ScaleDetector {
  final List<PlayerData> players;
  final String roomCode;
  final int localPlayerIndex;

  GamePhase phase = GamePhase.introAnimation;
  int currentPlayerIndex = 0;
  Map<PlayerData, int> initRolls = {};
  int currentDiceValue = 0;

  bool earnedBonusTurn = false;
  PlayerData? duelOpponent;
  int duelChallengerRoll = 0;
  bool isDuelDefenderTurn = false;

  int drawnCardId = 1;
  int tilesPerPlayer = 12;
  late int totalTiles;

  late TextComponent statusText;
  late DiceComponent dice;
  late RectangleComponent darkOverlay;

  late CardDeckComponent leftDeck;
  late CardDeckComponent rightDeck;
  DrawnCardComponent? activeDrawnCard;

  late PositionComponent boardContainer;
  double _startScale = 1.0;
  double _initialScale = 1.0;

  final List<TileComponent> boardTiles = [];
  final List<PlayerBaseComponent> playerBases = [];
  final List<PawnComponent> pawns = [];

  int serverEventCounter = 0;
  int localProcessedCounter = 0;

  AlkoChinczykGame(this.players, this.roomCode, this.localPlayerIndex) {
    totalTiles = players.length * tilesPerPlayer;
  }

  bool get isMyTurn {
    if (roomCode == 'LOCAL') return true;

    if (phase == GamePhase.duelRolling) {
      if (isDuelDefenderTurn) {
        return duelOpponent != null && players.indexOf(duelOpponent!) == localPlayerIndex;
      }
      return currentPlayerIndex == localPlayerIndex;
    }
    return currentPlayerIndex == localPlayerIndex;
  }

  @override
  Color backgroundColor() => const Color(0xFF141E30);

  @override
  Future<void> onLoad() async {
    super.onLoad();

    boardContainer = PositionComponent(position: size / 2, size: Vector2(1000, 1000), anchor: Anchor.center);
    _initialScale = size.x / 1100.0;
    boardContainer.scale = Vector2.all(_initialScale);
    add(boardContainer);

    _generateClassicBoard();

    Vector2 leftOrigin = Vector2(size.x * 0.25, size.y - 120);
    Vector2 rightOrigin = Vector2(size.x * 0.75, size.y - 120);
    leftDeck = CardDeckComponent(isLeft: true, position: leftOrigin, originPosition: leftOrigin)..opacity = 0;
    rightDeck = CardDeckComponent(isLeft: false, position: rightOrigin, originPosition: rightOrigin)..opacity = 0;
    add(leftDeck);
    add(rightDeck);

    darkOverlay = RectangleComponent(size: size, paint: Paint()..color = Colors.black.withOpacity(0.0), priority: 90);
    add(darkOverlay);

    statusText = TextComponent(
      text: 'ŁĄCZENIE Z GRĄ...',
      position: Vector2(size.x / 2, size.y / 2 - 80),
      anchor: Anchor.center,
      priority: 210,
      textRenderer: TextPaint(style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900, shadows: [Shadow(blurRadius: 8, color: Colors.black)])),
    );
    add(statusText);

    dice = DiceComponent(position: Vector2(-1000, -1000))..priority = 100;
    add(dice);

    if (roomCode != 'LOCAL') {
      await _restoreGameStateOrStart();
      _listenToFirebase();
    } else {
      _playIntroShuffleAnimation();
    }
  }

  void _syncUIState() {
    darkOverlay.paint = Paint()..color = (phase == GamePhase.playingMoving || phase == GamePhase.actionMenu) ? Colors.black.withOpacity(0.0) : Colors.black.withOpacity(0.85);

    if (phase == GamePhase.playingRolling || phase == GamePhase.initRolling || phase == GamePhase.duelRolling) {
      dice.position = Vector2(size.x / 2, size.y / 2 + 60);
      leftDeck.position = leftDeck.originPosition.clone();
      rightDeck.position = rightDeck.originPosition.clone();
    } else if (phase == GamePhase.waitingForCardPick) {
      dice.position = Vector2(-1000, -1000);
      leftDeck.position = Vector2(size.x / 2 - 70, size.y / 2 + 50);
      rightDeck.position = Vector2(size.x / 2 + 70, size.y / 2 + 50);
      leftDeck.isHighlighted = true; rightDeck.isHighlighted = true;
    } else if (phase == GamePhase.playingMoving) {
      dice.position = Vector2(-1000, -1000);
    }
    _updateUI();
  }

  Future<void> _restoreGameStateOrStart() async {
    var doc = await FirebaseFirestore.instance.collection('lobbies').doc(roomCode).get();
    if (doc.exists && doc.data()!.containsKey('eventCounter')) {
      serverEventCounter = (doc.data()!['eventCounter'] as num).toInt();
      localProcessedCounter = serverEventCounter;
    }

    if (doc.exists && doc.data()!.containsKey('gameState')) {
      var gs = doc.data()!['gameState'];
      currentPlayerIndex = (gs['currentPlayerIndex'] as num).toInt();
      phase = GamePhase.values.firstWhere((e) => e.name == gs['phase'], orElse: () => GamePhase.playingRolling);
      List<dynamic> steps = gs['pawnSteps'];

      for(int i = 0; i < pawns.length; i++) {
        pawns[i].stepCount = (steps[i] as num).toInt();
        if (pawns[i].stepCount != -1) {
          int playerStartIndex = players.indexOf(pawns[i].player) * tilesPerPlayer;
          int targetGlobalIndex = (playerStartIndex + pawns[i].stepCount) % totalTiles;
          pawns[i].position = boardTiles[targetGlobalIndex].position.clone();
        } else {
          pawns[i].position = pawns[i].basePosition.clone();
        }
      }
      _syncUIState();
    } else {
      _playIntroShuffleAnimation();
    }
  }

  void _listenToFirebase() {
    if (roomCode == 'LOCAL') return;
    FirebaseFirestore.instance.collection('lobbies').doc(roomCode).snapshots().listen((snapshot) {
      if (!snapshot.exists) return;
      var data = snapshot.data()!;

      if (data.containsKey('eventCounter')) {
        serverEventCounter = (data['eventCounter'] as num).toInt();
      }

      if (data.containsKey('lastEvent')) {
        var event = data['lastEvent'];
        int eventCounter = (event['counter'] as num?)?.toInt() ?? 0;

        if (eventCounter > localProcessedCounter) {
          localProcessedCounter = eventCounter;

          if (data.containsKey('gameState')) {
            var gs = data['gameState'];
            currentPlayerIndex = (gs['currentPlayerIndex'] as num).toInt();
            phase = GamePhase.values.firstWhere((e) => e.name == gs['phase'], orElse: () => GamePhase.playingRolling);
            List<dynamic> steps = gs['pawnSteps'];
            for(int i = 0; i < pawns.length; i++) {
              pawns[i].stepCount = (steps[i] as num).toInt();
              if (pawns[i].stepCount != -1) {
                int playerStartIndex = players.indexOf(pawns[i].player) * tilesPerPlayer;
                int targetGlobalIndex = (playerStartIndex + pawns[i].stepCount) % totalTiles;
                pawns[i].position = boardTiles[targetGlobalIndex].position.clone();
              } else {
                pawns[i].position = pawns[i].basePosition.clone();
              }
            }
            _syncUIState();
          }

          _processRemoteEvent(event);
        }
      }
    });
  }

  void pushEvent(String type, Map<String, dynamic> payload) {
    if (roomCode == 'LOCAL') return;

    serverEventCounter++;
    int nextCounter = serverEventCounter;
    payload['counter'] = nextCounter;
    payload['type'] = type;

    List<int> pawnSteps = pawns.map((p) => p.stepCount).toList();

    FirebaseFirestore.instance.collection('lobbies').doc(roomCode).update({
      'eventCounter': nextCounter,
      'lastEvent': payload,
      'gameState': {
        'currentPlayerIndex': currentPlayerIndex,
        'pawnSteps': pawnSteps,
        'phase': phase.name,
      }
    });
  }

  void _processRemoteEvent(Map<String, dynamic> event) {
    try {
      String type = event['type'];

      if (type == 'DICE_ROLL') {
        dice.startRollTo((event['value'] as num).toInt());
      } else if (type == 'PAWN_TAP') {
        int pIndex = (event['pIndex'] as num).toInt();
        int pId = (event['pId'] as num).toInt();
        var pawn = pawns.firstWhere((p) => players.indexOf(p.player) == pIndex && p.pawnId == pId);
        _handlePawnMoveLocal(pawn);
      } else if (type == 'DECK_TAP') {
        _executeDeckTapLocal((event['cardId'] as num).toInt());
      } else if (type == 'CARD_FLIP') {
        _executeCardFlipLocal();
      } else if (type == 'NEXT_TURN') {
        overlays.remove('DrinkChoiceMenu');
        startNextTurn();
      } else if (type == 'START_DUEL') {
        overlays.remove('DrinkChoiceMenu');
        overlays.remove('DuelOpponentMenu');
        int oppIndex = (event['oppIndex'] as num).toInt();
        startDuelLocal(players[oppIndex]);
      } else if (type == 'CARD_DONE') {
        overlays.remove('CardDrawMenu');
        activeDrawnCard?.removeFromParent();
        executeCardActionLocal((event['cardId'] as num).toInt());
      }
    } catch (e) {
      debugPrint('Błąd parsowania: $e');
    }
  }

  @override void onScaleStart(ScaleStartInfo info) { _startScale = boardContainer.scale.x; }
  @override void onScaleUpdate(ScaleUpdateInfo info) {
    double newScale = (_startScale * info.raw.scale).clamp(_initialScale * 0.6, _initialScale * 3.5);
    boardContainer.scale = Vector2.all(newScale);
    boardContainer.position += Vector2(info.raw.focalPointDelta.dx, info.raw.focalPointDelta.dy);
  }

  Future<void> _playIntroShuffleAnimation() async {
    List<IntroCard> flyingCards = [];
    final random = Random();

    for (int i = 0; i < 14; i++) {
      Vector2 startPos = i % 2 == 0 ? Vector2(-100, random.nextDouble() * size.y) : Vector2(size.x + 100, random.nextDouble() * size.y);
      var card = IntroCard(position: startPos);
      flyingCards.add(card); add(card);
      card.add(MoveToEffect(Vector2(size.x / 2 + (random.nextDouble() * 40 - 20), size.y / 2 + (random.nextDouble() * 40 - 20)), EffectController(duration: 0.6 + random.nextDouble() * 0.4, curve: Curves.easeOutBack)));
      card.add(RotateEffect.to(random.nextDouble() * pi - (pi/2), EffectController(duration: 0.8)));
    }

    await Future.delayed(const Duration(milliseconds: 1500));
    statusText.text = 'ROZDAWANIE...';

    for (int i = 0; i < flyingCards.length; i++) {
      Vector2 target = i % 2 == 0 ? leftDeck.position : rightDeck.position;
      flyingCards[i].add(MoveToEffect(target, EffectController(duration: 0.5, curve: Curves.easeInOutCubic)));
      flyingCards[i].add(RotateEffect.to(0, EffectController(duration: 0.5)));
    }

    await Future.delayed(const Duration(milliseconds: 600));

    for (var card in flyingCards) { remove(card); }
    leftDeck.opacity = 1; rightDeck.opacity = 1;
    darkOverlay.paint = Paint()..color = Colors.black.withOpacity(0.85);
    dice.position = Vector2(size.x / 2, size.y / 2 + 60);
    phase = GamePhase.initRolling;
    _updateUI();
  }

  void _generateClassicBoard() {
    double centerX = 500.0; double centerY = 500.0;
    double trackRadius = 340.0; double currentTileSize = 40.0; double baseSize = 120.0;

    for (int p = 0; p < players.length; p++) {
      double startAngle = (p / players.length) * 2 * pi - (pi / 2);
      double baseAngle = startAngle - (pi / totalTiles);

      var base = PlayerBaseComponent(player: players[p], position: Vector2(centerX + (trackRadius + 115) * cos(baseAngle), centerY + (trackRadius + 115) * sin(baseAngle)), size: Vector2(baseSize, baseSize));
      playerBases.add(base); boardContainer.add(base);

      double r = baseSize * 0.22; double offset = baseSize * 0.28;
      List<Vector2> pawnPositions = [Vector2(base.position.x - offset, base.position.y - offset), Vector2(base.position.x + offset, base.position.y - offset), Vector2(base.position.x - offset, base.position.y + offset), Vector2(base.position.x + offset, base.position.y + offset)];
      for (int i = 0; i < 4; i++) {
        var pawn = PawnComponent(player: players[p], pawnId: i, position: pawnPositions[i], size: Vector2(r * 2.4, r * 2.4));
        pawns.add(pawn); boardContainer.add(pawn);
      }

      double homeEntryAngle = startAngle - (2 * pi / totalTiles);
      for (int h = 0; h < 4; h++) {
        double dist = trackRadius - (h + 1.5) * (currentTileSize + 5);
        var homeTile = TileComponent(index: -1, type: TileType.home, baseColor: players[p].color, position: Vector2(centerX + dist * cos(homeEntryAngle), centerY + dist * sin(homeEntryAngle)), size: Vector2(currentTileSize, currentTileSize));
        boardContainer.add(homeTile);
      }

      for (int t = 0; t < tilesPerPlayer; t++) {
        int globalIndex = p * tilesPerPlayer + t;
        double tileAngle = (globalIndex / totalTiles) * 2 * pi - (pi / 2);
        TileType type = TileType.normal;
        if (t == 0) type = TileType.start;
        else if (t == 4 || t == 9) type = TileType.drink;
        else if (t == 6 || t == 11) type = TileType.card;

        var tile = TileComponent(index: globalIndex, type: type, baseColor: players[p].color, position: Vector2(centerX + trackRadius * cos(tileAngle), centerY + trackRadius * sin(tileAngle)), size: Vector2(currentTileSize, currentTileSize));
        boardTiles.add(tile); boardContainer.add(tile);
      }
    }
  }

  String _getStatusText() {
    String activeName = players[currentPlayerIndex].name;
    bool isMe = isMyTurn;

    if (phase == GamePhase.initRolling) return isMe ? 'TWÓJ RZUT!\n(Kliknij kostkę)' : 'CZEKAJ...\nRzuca: $activeName';
    if (phase == GamePhase.playingRolling) return isMe ? 'TWOJA TURA!\n(Rzuć kostką)' : 'CZEKAJ...\nTura gracza: $activeName';
    if (phase == GamePhase.duelRolling) return isDuelDefenderTurn
        ? (isMe ? 'BROŃ SIĘ!\n(Rzuć kostką)' : 'CZEKAJ...\nObrona: ${duelOpponent!.name}')
        : (isMe ? 'ATAKUJESZ!\n(Rzuć kostką)' : 'CZEKAJ...\nAtakuje: $activeName');
    if (phase == GamePhase.waitingForCardPick) return isMe ? 'KARTA!\nWybierz talię!' : 'CZEKAJ...\n$activeName losuje kartę';
    if (phase == GamePhase.waitingForCardFlip) return isMe ? 'KLIKNIJ KARTĘ\nABY ODKRYĆ!' : 'CZEKAJ...\n$activeName odkrywa kartę';
    if (phase == GamePhase.animatingMove) return 'WYRZUCONO: $currentDiceValue';
    if (phase == GamePhase.actionMenu) return '';

    return isMe ? 'WYRZUCONO: $currentDiceValue\nWybierz swój pionek!' : 'WYRZUCONO: $currentDiceValue\n$activeName wybiera pionek...';
  }

  void _updateUI() {
    if (phase == GamePhase.introAnimation) return;
    statusText.text = _getStatusText();
    Color textColor = Colors.white;
    if (phase == GamePhase.duelRolling && isDuelDefenderTurn) textColor = duelOpponent!.color;
    else textColor = players[currentPlayerIndex].color;

    statusText.textRenderer = TextPaint(
      style: TextStyle(color: textColor, fontSize: (phase == GamePhase.playingMoving || phase == GamePhase.duelRolling || phase == GamePhase.waitingForCardPick) ? 26 : 22, fontWeight: FontWeight.w900, letterSpacing: 1.5, shadows: const [Shadow(blurRadius: 8, color: Colors.black, offset: Offset(2, 2))]),
    );
  }

  void startNextTurn() {
    if (!earnedBonusTurn) {
      currentPlayerIndex++;
      if (currentPlayerIndex >= players.length) currentPlayerIndex = 0;
    }
    earnedBonusTurn = false;
    phase = GamePhase.playingRolling;
    _syncUIState();
  }

  Future<void> onDiceRolledLocal(int value) async {
    if (phase == GamePhase.initRolling) {
      initRolls[players[currentPlayerIndex]] = value; currentDiceValue = value; phase = GamePhase.animatingMove; _syncUIState();
      await Future.delayed(const Duration(milliseconds: 1000));
      currentPlayerIndex++;
      if (currentPlayerIndex >= players.length) {
        var winner = initRolls.entries.reduce((a, b) => a.value > b.value ? a : b).key;
        currentPlayerIndex = players.indexOf(winner); phase = GamePhase.playingRolling;
      } else { phase = GamePhase.initRolling; }
      _syncUIState();
    }
    else if (phase == GamePhase.playingRolling) {
      currentDiceValue = value; phase = GamePhase.animatingMove; _syncUIState();
      await Future.delayed(const Duration(milliseconds: 1200));

      bool canMove = false;
      for (var pawn in pawns.where((p) => p.player == players[currentPlayerIndex])) {
        if (pawn.stepCount != -1) canMove = true;
        if (pawn.stepCount == -1 && (value == 1 || value == 6)) canMove = true;
      }

      if (!canMove) {
        statusText.text = "BRAK RUCHU!\n(Potrzebujesz 1 lub 6)";
        await Future.delayed(const Duration(seconds: 2));
        startNextTurn(); return;
      }
      phase = GamePhase.playingMoving; _syncUIState();
      statusText.position = Vector2(size.x / 2, 70);
    }
    else if (phase == GamePhase.duelRolling) {
      phase = GamePhase.animatingMove; _syncUIState();
      await Future.delayed(const Duration(milliseconds: 1200));

      if (!isDuelDefenderTurn) {
        duelChallengerRoll = value; isDuelDefenderTurn = true; phase = GamePhase.duelRolling;
        dice.currentValue = Random().nextInt(6) + 1; _syncUIState();
      } else {
        int defenderRoll = value; String winnerName = ""; String loserName = "";

        if (duelChallengerRoll > defenderRoll) { winnerName = players[currentPlayerIndex].name; loserName = duelOpponent!.name; }
        else if (defenderRoll > duelChallengerRoll) { winnerName = duelOpponent!.name; loserName = players[currentPlayerIndex].name; }

        String resultText = "WYNIKI POJEDYNKU:\n\n${players[currentPlayerIndex].name} rzuca: $duelChallengerRoll\n${duelOpponent!.name} rzuca: $defenderRoll\n\n";
        if (duelChallengerRoll == defenderRoll) { resultText += "⚖️ REMIS! OBOJE PIJECIE! 🍻"; }
        else { resultText += "🏆 WYGRYWA: $winnerName\n🍺 PIJE: $loserName (mniej oczek)"; }

        statusText.text = resultText; statusText.position = Vector2(size.x / 2, size.y / 2 - 140);
        dice.position = Vector2(-1000, -1000);
        await Future.delayed(const Duration(seconds: 5));
        startNextTurn();
      }
    }
  }

  Future<void> _handlePawnMoveLocal(PawnComponent pawn) async {
    phase = GamePhase.animatingMove; _syncUIState();
    int playerStartIndex = players.indexOf(pawn.player) * tilesPerPlayer;
    if (pawn.stepCount == -1) pawn.stepCount = 0; else pawn.stepCount += currentDiceValue;

    int targetGlobalIndex = (playerStartIndex + pawn.stepCount) % totalTiles;
    TileComponent targetTile = boardTiles[targetGlobalIndex];
    pawn.add(MoveToEffect(targetTile.position, EffectController(duration: 0.5, curve: Curves.easeInOut)));
    await Future.delayed(const Duration(milliseconds: 500));

    if (targetTile.type != TileType.start) {
      var victims = pawns.where((p) => p.player != pawn.player && p.stepCount != -1 && (players.indexOf(p.player) * tilesPerPlayer + p.stepCount) % totalTiles == targetGlobalIndex).toList();
      if (victims.isNotEmpty) {
        for (var victim in victims) {
          var dramaOverlay = RectangleComponent(size: Vector2(3000, 3000), position: Vector2.zero(), anchor: Anchor.center, paint: Paint()..color = Colors.black.withOpacity(0.85), priority: 200);
          boardContainer.add(dramaOverlay);
          var announcement = TextComponent(
            text: 'ELIMINACJA!\n${pawn.player.name} rozjeżdża\n${victim.player.name}!\n\n${victim.player.name} PIJE KARNIAKA! 🍺',
            textRenderer: TextPaint(style: const TextStyle(color: Colors.redAccent, fontSize: 26, fontWeight: FontWeight.w900, shadows: [Shadow(blurRadius: 15, color: Colors.black, offset: Offset(3, 3))])),
            position: Vector2(size.x / 2, size.y / 2 - 30), anchor: Anchor.center,
          )..priority = 210;
          add(announcement);
          victim.priority = 220;
          victim.add(MoveByEffect(Vector2(0, -1500), EffectController(duration: 1.5, curve: Curves.easeInCirc)));
          victim.add(RotateEffect.by(pi * 12, EffectController(duration: 1.5)));
          victim.add(ScaleEffect.to(Vector2.zero(), EffectController(duration: 1.5)));

          await Future.delayed(const Duration(milliseconds: 2500));
          remove(announcement); boardContainer.remove(dramaOverlay);
          victim.stepCount = -1; victim.position = victim.basePosition.clone();
          victim.scale = Vector2.all(1.0); victim.angle = 0; victim.priority = 10;
        }
      }
    }

    if (currentDiceValue == 6) earnedBonusTurn = true;

    if (targetTile.type == TileType.drink) { phase = GamePhase.actionMenu; _syncUIState(); overlays.add('DrinkChoiceMenu'); }
    else if (targetTile.type == TileType.card) {
      phase = GamePhase.waitingForCardPick; _syncUIState();
      statusText.position = Vector2(size.x / 2, size.y / 2 - 140);
    }
    else {
      if (earnedBonusTurn) {
        statusText.text = 'SZÓSTKA!\n${pawn.player.name} rzuca jeszcze raz!'; statusText.position = Vector2(size.x / 2, size.y / 2);
        await Future.delayed(const Duration(seconds: 2));
      }
      startNextTurn();
    }
  }

  void startDuelLocal(PlayerData opponent) {
    duelOpponent = opponent; isDuelDefenderTurn = false; phase = GamePhase.duelRolling;
    _syncUIState();
    dice.currentValue = Random().nextInt(6) + 1;
    statusText.position = Vector2(size.x / 2, size.y / 2 - 80);
  }

  void _executeDeckTapLocal(int cardId) async {
    phase = GamePhase.animatingMove; leftDeck.isHighlighted = false; rightDeck.isHighlighted = false; statusText.text = "";
    drawnCardId = cardId;
    leftDeck.add(MoveToEffect(leftDeck.originPosition, EffectController(duration: 0.5, curve: Curves.easeInOut)));
    rightDeck.add(MoveToEffect(rightDeck.originPosition, EffectController(duration: 0.5, curve: Curves.easeInOut)));

    activeDrawnCard = DrawnCardComponent(position: Vector2(size.x / 2, size.y / 2))..priority = 200;
    add(activeDrawnCard!);
    activeDrawnCard!.add(ScaleEffect.to(Vector2(1.5, 1.5), EffectController(duration: 0.5)));

    await Future.delayed(const Duration(milliseconds: 600));
    phase = GamePhase.waitingForCardFlip; statusText.position = Vector2(size.x / 2, size.y / 2 - 160); _updateUI();
  }

  void _executeCardFlipLocal() async {
    phase = GamePhase.animatingMove; statusText.text = "";
    activeDrawnCard!.add(ScaleEffect.to(Vector2(0, 1.5), EffectController(duration: 0.2, curve: Curves.easeIn)));
    await Future.delayed(const Duration(milliseconds: 200));
    activeDrawnCard!.isFlipped = true;
    activeDrawnCard!.add(ScaleEffect.to(Vector2(1.5, 1.5), EffectController(duration: 0.2, curve: Curves.easeOut)));
    await Future.delayed(const Duration(milliseconds: 200));
    phase = GamePhase.actionMenu; overlays.add('CardDrawMenu');
  }

  Future<void> executeCardActionLocal(int cardId) async {
    if (earnedBonusTurn) {
      statusText.text = 'SZÓSTKA!\n${players[currentPlayerIndex].name} rzuca jeszcze raz!'; statusText.position = Vector2(size.x / 2, size.y / 2);
      await Future.delayed(const Duration(seconds: 2));
    }
    startNextTurn();
  }
}

// ----------------------------------------------------------------------
// WIDŻETY FLUTTERA I MENU Z OPTYMALIZACJĄ (NATYCHMIASTOWE ZAMYKANIE)
// ----------------------------------------------------------------------

class GameBoardScreen extends StatelessWidget {
  final List<PlayerData> players;
  final String roomCode;
  final int localPlayerIndex;

  const GameBoardScreen({Key? key, required this.players, required this.roomCode, required this.localPlayerIndex}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: GameWidget<AlkoChinczykGame>(
          game: AlkoChinczykGame(players, roomCode, localPlayerIndex),
          overlayBuilderMap: {
            'DrinkChoiceMenu': (context, game) => DrinkChoiceOverlay(game: game),
            'DuelOpponentMenu': (context, game) => DuelOpponentOverlay(game: game),
            'CardDrawMenu': (context, game) => CardDrawOverlay(game: game),
          },
        )
    );
  }
}

class DrinkChoiceOverlay extends StatelessWidget {
  final AlkoChinczykGame game;
  const DrinkChoiceOverlay({Key? key, required this.game}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    if (game.roomCode != 'LOCAL' && !game.isMyTurn) {
      return Center(child: Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.purpleAccent, width: 2)), child: Text('Czekamy na decyzję gracza:\n${game.players[game.currentPlayerIndex].name}...', textAlign: TextAlign.center, style: GoogleFonts.bangers(fontSize: 30, color: Colors.amberAccent))));
    }

    return Center(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9, padding: const EdgeInsets.all(25),
        decoration: BoxDecoration(color: Colors.black.withOpacity(0.9), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.purpleAccent, width: 3), boxShadow: [BoxShadow(color: Colors.purpleAccent.withOpacity(0.5), blurRadius: 20)]),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('POLE PICIA! 🍺', style: GoogleFonts.bangers(fontSize: 40, color: Colors.amberAccent)), const SizedBox(height: 15),
            Text('${game.players[game.currentPlayerIndex].name}, co robisz?', style: GoogleFonts.lato(fontSize: 18, color: Colors.white), textAlign: TextAlign.center), const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15)),
              onPressed: () {
                game.overlays.remove('DrinkChoiceMenu');
                if (game.roomCode == 'LOCAL') game.startNextTurn(); else game.pushEvent('NEXT_TURN', {});
              },
              child: Text('Piję sam (Karniak)', style: GoogleFonts.bangers(fontSize: 22, color: Colors.white)),
            ),
            const SizedBox(height: 15),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15)),
              onPressed: () {
                game.overlays.remove('DrinkChoiceMenu');
                game.overlays.add('DuelOpponentMenu');
              },
              child: Text('WYZWANIE! (Pojedynek)', style: GoogleFonts.bangers(fontSize: 22, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}

class DuelOpponentOverlay extends StatelessWidget {
  final AlkoChinczykGame game;
  const DuelOpponentOverlay({Key? key, required this.game}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    if (game.roomCode != 'LOCAL' && !game.isMyTurn) return const SizedBox.shrink();

    var currentPlayer = game.players[game.currentPlayerIndex];
    var opponents = game.players.where((p) => p != currentPlayer).toList();
    return Center(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.9, height: 400, padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Colors.black.withOpacity(0.9), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.redAccent, width: 3)),
        child: Column(
          children: [
            Text('WYBIERZ OFIARĘ ⚔️', style: GoogleFonts.bangers(fontSize: 35, color: Colors.redAccent)), const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: opponents.length,
                itemBuilder: (context, index) {
                  return Card(
                    color: Colors.white10,
                    child: ListTile(
                      title: Text(opponents[index].name, style: GoogleFonts.bangers(fontSize: 22, color: opponents[index].color)),
                      trailing: const Icon(Icons.sports_kabaddi, color: Colors.white),
                      onTap: () {
                        game.overlays.remove('DuelOpponentMenu');
                        if (game.roomCode == 'LOCAL') {
                          game.startDuelLocal(opponents[index]);
                        } else {
                          game.pushEvent('START_DUEL', {'oppIndex': game.players.indexOf(opponents[index])});
                        }
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CardDrawOverlay extends StatelessWidget {
  final AlkoChinczykGame game;
  const CardDrawOverlay({Key? key, required this.game}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    String imagePath = 'assets/images/cards/${game.drawnCardId}.png';

    return Center(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.85,
        height: MediaQuery.of(context).size.height * 0.7,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Colors.black.withOpacity(0.95), borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.pinkAccent, width: 4), boxShadow: [BoxShadow(color: Colors.pinkAccent.withOpacity(0.4), blurRadius: 30)]),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('KARTA NR ${game.drawnCardId}', style: GoogleFonts.bangers(fontSize: 35, color: Colors.pinkAccent)),
            const SizedBox(height: 15),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.asset(imagePath, fit: BoxFit.contain, errorBuilder: (context, error, stackTrace) {
                  return Container(alignment: Alignment.center, color: Colors.white10, child: Text('Błąd wczytywania karty', textAlign: TextAlign.center, style: const TextStyle(color: Colors.red, fontSize: 18)));
                }),
              ),
            ),
            const SizedBox(height: 20),

            if (game.roomCode == 'LOCAL' || game.isMyTurn)
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.pinkAccent, padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                onPressed: () {
                  game.overlays.remove('CardDrawMenu');
                  game.activeDrawnCard?.removeFromParent();

                  if (game.roomCode == 'LOCAL') {
                    game.executeCardActionLocal(game.drawnCardId);
                  } else {
                    game.pushEvent('CARD_DONE', {'cardId': game.drawnCardId});
                  }
                },
                child: Text('ZROBIONE!', style: GoogleFonts.bangers(fontSize: 28, color: Colors.white)),
              )
            else
              Text('Czekamy na gracza...', style: GoogleFonts.bangers(fontSize: 28, color: Colors.white70))
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------------------------
// ZOPTYMALIZOWANE KOMPONENTY WIZUALNE
// ----------------------------------------------------------------------

class CustomCardBack {
  static final textPaintTop = TextPaint(style: const TextStyle(color: Colors.pinkAccent, fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.2));
  static final textPaintBottom = TextPaint(style: const TextStyle(color: Colors.pinkAccent, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1.2));
  static final heartPaint = TextPaint(style: const TextStyle(fontSize: 24));

  static void draw(Canvas canvas, Vector2 size) {
    final rect = RRect.fromRectAndRadius(size.toRect(), const Radius.circular(12));
    canvas.drawRRect(rect.shift(const Offset(4, 4)), Paint()..color = Colors.black45);
    canvas.drawRRect(rect, Paint()..color = const Color(0xFF111111));
    canvas.drawRRect(rect, Paint()..color = Colors.pinkAccent..style = PaintingStyle.stroke..strokeWidth = 3);
    textPaintTop.render(canvas, 'CERTIFIED', Vector2(size.x / 2, size.y * 0.25), anchor: Anchor.center);
    heartPaint.render(canvas, '💖', Vector2(size.x / 2, size.y * 0.5), anchor: Anchor.center);
    textPaintBottom.render(canvas, 'BISEKS', Vector2(size.x / 2, size.y * 0.75), anchor: Anchor.center);
  }
}

class CustomCardFront {
  static void draw(Canvas canvas, Vector2 size) {
    final rect = RRect.fromRectAndRadius(size.toRect(), const Radius.circular(12));
    canvas.drawRRect(rect.shift(const Offset(4, 4)), Paint()..color = Colors.black45);
    canvas.drawRRect(rect, Paint()..color = Colors.white);
    canvas.drawRRect(rect, Paint()..color = Colors.pinkAccent..style = PaintingStyle.stroke..strokeWidth = 4);
  }
}

class IntroCard extends PositionComponent {
  IntroCard({required Vector2 position}) : super(position: position, size: Vector2(105, 150), anchor: Anchor.center) { priority = 200; }
  @override void render(Canvas canvas) { CustomCardBack.draw(canvas, size); }
}

class CardDeckComponent extends PositionComponent with TapCallbacks, HasGameRef<AlkoChinczykGame> {
  final bool isLeft; bool isHighlighted = false; double opacity = 1.0; Vector2 originPosition;
  CardDeckComponent({required this.isLeft, required Vector2 position, required this.originPosition}) : super(position: position, size: Vector2(105, 150), anchor: Anchor.center) { priority = 150; }

  @override void render(Canvas canvas) {
    if (opacity == 0) return;
    CustomCardBack.draw(canvas, size); CustomCardBack.draw(canvas, size - Vector2(2, 2)); CustomCardBack.draw(canvas, size - Vector2(4, 4));
    if (isHighlighted) {
      final rect = RRect.fromRectAndRadius((size - Vector2(4, 4)).toRect(), const Radius.circular(12));
      canvas.drawRRect(rect, Paint()..color = Colors.yellowAccent.withOpacity(0.5)..style = PaintingStyle.stroke..strokeWidth = 10);
      canvas.drawRRect(rect, Paint()..color = Colors.yellowAccent..style = PaintingStyle.stroke..strokeWidth = 4);
    }
  }

  @override void onTapDown(TapDownEvent event) {
    if (!gameRef.isMyTurn) return;
    if (gameRef.phase != GamePhase.waitingForCardPick) return;
    int cardId = Random().nextInt(97) + 1;
    if (gameRef.roomCode == 'LOCAL') gameRef._executeDeckTapLocal(cardId); else gameRef.pushEvent('DECK_TAP', {'cardId': cardId});
  }
}

class DrawnCardComponent extends PositionComponent with TapCallbacks, HasGameRef<AlkoChinczykGame> {
  bool isFlipped = false;
  DrawnCardComponent({required Vector2 position}) : super(position: position, size: Vector2(105, 150), anchor: Anchor.center) { priority = 200; }
  @override void render(Canvas canvas) { if (!isFlipped) CustomCardBack.draw(canvas, size); else CustomCardFront.draw(canvas, size); }

  @override void onTapDown(TapDownEvent event) async {
    if (!gameRef.isMyTurn) return;
    if (gameRef.phase != GamePhase.waitingForCardFlip) return;
    if (gameRef.roomCode == 'LOCAL') gameRef._executeCardFlipLocal(); else gameRef.pushEvent('CARD_FLIP', {});
  }
}

class PawnComponent extends PositionComponent with TapCallbacks, HasGameRef<AlkoChinczykGame> {
  final PlayerData player; final int pawnId; int stepCount = -1; late Vector2 basePosition;
  PawnComponent({required this.player, required this.pawnId, required Vector2 position, required Vector2 size}) : super(position: position, size: size, anchor: Anchor.center) { basePosition = position.clone(); priority = 10; }

  @override void render(Canvas canvas) {
    double r = size.x / 2; Offset center = Offset(r, r);
    canvas.drawCircle(center + const Offset(2, 4), r, Paint()..color = Colors.black45);
    canvas.drawCircle(center, r, Paint()..color = player.color);
    canvas.drawCircle(center - Offset(r * 0.2, r * 0.2), r * 0.5, Paint()..color = Colors.white.withOpacity(0.4));
    canvas.drawCircle(center, r, Paint()..color = Colors.black87..style = PaintingStyle.stroke..strokeWidth = 2.5);
  }

  @override void onTapDown(TapDownEvent event) {
    if (!gameRef.isMyTurn) return;
    if (gameRef.phase != GamePhase.playingMoving || player != gameRef.players[gameRef.currentPlayerIndex]) return;
    if (stepCount == -1 && gameRef.currentDiceValue != 1 && gameRef.currentDiceValue != 6) {
      gameRef.statusText.text = 'Tym nie ruszysz!\nWybierz pionek na trasie!'; return;
    }
    if (gameRef.roomCode == 'LOCAL') {
      gameRef._handlePawnMoveLocal(this);
    } else {
      gameRef.pushEvent('PAWN_TAP', {'pIndex': gameRef.players.indexOf(player), 'pId': pawnId});
    }
  }
}

class PlayerBaseComponent extends PositionComponent {
  final PlayerData player;
  PlayerBaseComponent({required this.player, required Vector2 position, required Vector2 size}) : super(position: position, size: size, anchor: Anchor.center);
  @override void render(Canvas canvas) {
    double r = size.x / 2; Offset center = Offset(r, r);
    canvas.drawCircle(center + const Offset(3, 5), r, Paint()..color = Colors.black45);
    canvas.drawCircle(center, r, Paint()..color = player.color.withOpacity(0.35));
    canvas.drawCircle(center, r, Paint()..color = Colors.white54..style = PaintingStyle.stroke..strokeWidth = 3);
    double dotR = size.x * 0.22; double offset = size.x * 0.28;
    List<Offset> positions = [Offset(r - offset, r - offset), Offset(r + offset, r - offset), Offset(r - offset, r + offset), Offset(r + offset, r + offset)];
    for (var pos in positions) { canvas.drawCircle(pos, dotR, Paint()..color = Colors.black26); canvas.drawCircle(pos, dotR, Paint()..color = Colors.black54..style = PaintingStyle.stroke..strokeWidth = 1.5); }
  }
}

class TileComponent extends PositionComponent {
  TileType type; final int index; Color? baseColor;
  late TextPaint _cachedTextPaint;
  String _text = ''; Color _tileColor = Colors.white; Color _strokeColor = Colors.black; double _strokeWidth = 2.0;

  TileComponent({required this.index, required this.type, required Vector2 position, required Vector2 size, this.baseColor}) : super(position: position, size: size, anchor: Anchor.center) {
    Color textColor = Colors.black;
    if (type == TileType.drink) { _tileColor = Colors.amber; _text = 'PIJ'; }
    else if (type == TileType.card) { _tileColor = Colors.deepPurpleAccent; _text = '?'; textColor = Colors.white; }
    else if (type == TileType.start) { _tileColor = baseColor ?? Colors.white; _text = 'START'; textColor = Colors.white; _strokeColor = Colors.white; _strokeWidth = 3.0; }
    else if (type == TileType.home) { _tileColor = baseColor?.withOpacity(0.5) ?? Colors.white; _strokeColor = baseColor ?? Colors.black; }

    _cachedTextPaint = TextPaint(style: TextStyle(color: textColor, fontSize: type == TileType.start || type == TileType.drink ? size.x * 0.35 : size.x * 0.6, fontWeight: FontWeight.w900));
  }

  @override void render(Canvas canvas) {
    Offset center = Offset(size.x / 2, size.y / 2); double r = size.x / 2;
    canvas.drawCircle(center + const Offset(2, 3), r, Paint()..color = Colors.black45);
    canvas.drawCircle(center, r, Paint()..color = _tileColor);
    canvas.drawCircle(center, r, Paint()..color = _strokeColor..style = PaintingStyle.stroke..strokeWidth = _strokeWidth);

    if (_text.isNotEmpty) {
      _cachedTextPaint.render(canvas, _text, Vector2(size.x / 2, size.y / 2), anchor: Anchor.center);
    }
  }
}

class DiceComponent extends PositionComponent with TapCallbacks, HasGameRef<AlkoChinczykGame> {
  int currentValue = 6; bool isRolling = false; final Random _random = Random(); double _rollTimer = 0; int _rollTicks = 0;
  int _targetValue = 6;

  DiceComponent({required Vector2 position}) : super(position: position, size: Vector2(80, 80), anchor: Anchor.center);

  void startRollTo(int targetValue) {
    if (isRolling) return;
    _targetValue = targetValue; isRolling = true; _rollTicks = 0;
  }

  @override void update(double dt) {
    super.update(dt);
    if (isRolling) {
      _rollTimer += dt;
      if (_rollTimer > 0.08) {
        _rollTimer = 0; currentValue = _random.nextInt(6) + 1; _rollTicks++;
        if (_rollTicks > 12) { isRolling = false; currentValue = _targetValue; gameRef.onDiceRolledLocal(currentValue); }
      }
    }
  }

  @override void render(Canvas canvas) {
    final backgroundPaint = Paint()..color = Colors.white;
    final rect = RRect.fromRectAndRadius(size.toRect(), const Radius.circular(15));
    canvas.drawRRect(rect.shift(const Offset(4, 6)), Paint()..color = Colors.black45);
    canvas.drawRRect(rect, backgroundPaint);
    final dotPaint = Paint()..color = Colors.black;
    final double centerX = size.x / 2; final double centerY = size.y / 2;
    final double offset = size.x / 4; final double dotRadius = 7;
    void drawDot(double x, double y) { canvas.drawCircle(Offset(x, y), dotRadius, dotPaint); }
    if (currentValue.isOdd) drawDot(centerX, centerY);
    if (currentValue > 1) { drawDot(centerX - offset, centerY - offset); drawDot(centerX + offset, centerY + offset); }
    if (currentValue > 3) { drawDot(centerX + offset, centerY - offset); drawDot(centerX - offset, centerY + offset); }
    if (currentValue == 6) { drawDot(centerX - offset, centerY); drawDot(centerX + offset, centerY); }
  }

  @override void onTapDown(TapDownEvent event) {
    if (!gameRef.isMyTurn) return;
    if (!isRolling && (gameRef.phase == GamePhase.initRolling || gameRef.phase == GamePhase.playingRolling || gameRef.phase == GamePhase.duelRolling)) {
      int val = _random.nextInt(6) + 1;
      if (gameRef.roomCode == 'LOCAL') startRollTo(val); else gameRef.pushEvent('DICE_ROLL', {'value': val});
    }
  }
}