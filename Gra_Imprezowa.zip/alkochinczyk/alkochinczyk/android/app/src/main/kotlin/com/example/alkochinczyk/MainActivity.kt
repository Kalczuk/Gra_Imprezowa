package com.example.alkochinczyk

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
