import 'package:flutter_test/flutter_test.dart';
import 'package:alkochinczyk/main.dart';

void main() {
  testWidgets('App loads smoke test', (WidgetTester tester) async {
    // Odpalamy Twoją klasę AlkoChinczykApp zamiast domyślnego MyApp
    await tester.pumpWidget(const AlkoChinczykApp());

    // Test po prostu sprawdza, czy aplikacja potrafi się uruchomić bez wysypania
    expect(find.byType(AlkoChinczykApp), findsOneWidget);
  });
}